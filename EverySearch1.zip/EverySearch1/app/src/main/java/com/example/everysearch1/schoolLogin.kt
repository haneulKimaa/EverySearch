package com.example.everysearch1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_findschool.*
import kotlinx.android.synthetic.main.activity_school_login.*

class schoolLogin : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_school_login)

        button3.setOnClickListener {
            //val nextIntent = Intent(this, onBackPressed()::class.java)
            //startActivity(nextIntent)
        }
        button6.setOnClickListener(){
            //val nextIntent = Intent(this, onBackPressed()::class.java)
            //startActivity(nextIntent)
        }
        button4.setOnClickListener(){
            val nextIntent = Intent(this, navigation::class.java)
            startActivity(nextIntent)
        }
    }
}
