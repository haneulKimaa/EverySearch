package com.example.everysearch1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_findschool.*

class findschoolActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_findschool)

        button2.setOnClickListener(){
            val nextIntent = Intent(this, mainsearch()::class.java) //수정해야함.onBackPressed()
            startActivity(nextIntent)
        }

    }
}
